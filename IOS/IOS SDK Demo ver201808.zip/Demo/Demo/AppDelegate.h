//
//  AppDelegate.h
//  Demo
//
//  Created by smarnet on 2018/7/17.
//  Copyright © 2018年 smarnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

