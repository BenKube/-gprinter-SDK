//
//  CtrlViewController.h
//  GSDK
//
//  Created by 猿史森林 on 2018/6/16.
//  Copyright © 2018年 Smarnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CtrlViewController : UIViewController

@end
